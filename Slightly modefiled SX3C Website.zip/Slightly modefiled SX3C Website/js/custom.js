
$(document).ready(function(){
	$('.menu-toggle').click(function(){
		$('.menu-toggle').toggleClass('nav-active');
		$('.menu').toggleClass('nav-active');
	})
})